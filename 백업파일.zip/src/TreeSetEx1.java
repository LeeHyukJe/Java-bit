import java.util.*;
public class TreeSetEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet set=new TreeSet();
		
		String from="b";
		String to="d";
		
		set.add("abc");
		set.add("car");
		set.add("dance");
		set.add("elephant");
		set.add("flower");
	}

}
